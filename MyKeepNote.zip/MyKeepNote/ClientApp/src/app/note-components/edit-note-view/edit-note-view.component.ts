import { Component, OnInit, Inject } from '@angular/core';
import { Note } from '../../models/note';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { NotesService } from '../../services/notes.service';

@Component({
  selector: 'app-edit-note-view',
  templateUrl: './edit-note-view.component.html',
  styleUrls: ['./edit-note-view.component.css']
})
export class EditNoteViewComponent implements OnInit {
  note: Note;
  states: Array<string> = ['not-started', 'started', 'completed'];
  errMessage: string;
  // edit noteview component used to display the popup with preloaded values 
  constructor(private dialogRef: MatDialogRef<EditNoteViewComponent>,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private noteService: NotesService) { }

  ngOnInit() {
    this.note = new Note();
    //this.note = this.noteService.getNoteById(parseInt(this.data.noteId, 0));
    console.log("note id: " + parseInt(this.data.noteId, 0));
    this.noteService.getNotesById(parseInt(this.data.noteId, 0)).subscribe(
      data => {
        console.log("data=" + JSON.stringify(data));
        this.note = data;
      },
      error => {
        console.log("error="+ JSON.stringify(error));
        this.errMessage = error.message;
      }
    );
  }

  onSave() {
    //this.noteService.editNote(this.note).subscribe(
    //  editNote => this.dialogRef.close(),
    //  err => this.errMessage = err.message
    //);
  }
}
