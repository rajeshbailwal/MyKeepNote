import { Injectable, Inject } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Note } from '../models/note';

@Injectable()
export class NotesService {
  myAppUrl: string = "";

  constructor(private _http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this.myAppUrl = baseUrl;
  }

  getNotes(): Observable<Array<Note>> {
    return this._http.get<Array<Note>>(this.myAppUrl + 'api/SampleData/GetNotes');
  }

  getNotesById(noteId): Observable<Note> {
    return this._http.get<Note>(this.myAppUrl + 'api/SampleData/GetNotesById/' + noteId);
  }


  addNote(note: Note): Observable<Note> {
    //return this.http.post<Note>('http://localhost:3000/api/v1/notes', note);
    return null;
  }
}
