import { Component, OnInit } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { Note } from '../models/note';
import { NotesService } from '../services/notes.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  note: Note = new Note();
  notes: Array<Note> = [];
  errMessage: string;

  constructor(private notesService: NotesService, private routerService: RouterService) { }

  ngOnInit() {
    this.notesService.getNotes().subscribe(
      data => this.notes = data,
      error => {
        console.log(JSON.stringify(error));
        this.errMessage = error.message;
      }
    );
  }

  takeNotes() {
    this.errMessage = '';
    const formData = this.note;
    event.preventDefault();


    if (!formData.title || formData.title.length === 0 || !formData.text || formData.text.length === 0) {
      this.errMessage = `Title and Text both are required fields`;
    } else {
      this.notes.push(this.note);
      this.notesService.addNote(this.note).subscribe(
        data => { },
        error => {
          const index: number = this.notes.findIndex(note => note.title === this.note.title);
          this.notes.splice(index, 1);
          if (error.status === 404) {
            this.errMessage = error.message;
          } else {
            this.errMessage = error.message;
          }
        }
      );
      this.note = new Note();
    }
  }

  //openEditView() {
  //  this.routerService.routeToEditNoteView(this.note.id);
  //  //console.log(this.note);
  //}

}
