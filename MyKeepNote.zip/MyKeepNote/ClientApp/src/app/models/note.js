"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Note = /** @class */ (function () {
    function Note() {
        this.title = '';
        this.text = '';
        this.state = 'not-started'; // default state
    }
    return Note;
}());
exports.Note = Note;
//# sourceMappingURL=note.js.map