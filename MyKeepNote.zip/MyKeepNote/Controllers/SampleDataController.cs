using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;

namespace KeepNote.Controllers
{
    [Route("api/[controller]")]
    public class SampleDataController : Controller
    {
        private static List<Notes> lstNotes = new List<Notes>(){
            new Notes { Id = 1, Title = "Test1", Text = "This is a test note1", Tags = new List<string> { "C#", "Test", "Angular" } },
                new Notes { Id = 2, Title = "Test2", Text = "This is a test note2" },
                new Notes { Id = 3, Title = "Test3", Text = "This is a test note3" }
        };

        private static string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        [HttpGet("[action]")]
        public IEnumerable<WeatherForecast> WeatherForecasts()
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                DateFormatted = DateTime.Now.AddDays(index).ToString("d"),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            });
        }

        [HttpGet("[action]")]
        public IEnumerable<Notes> GetNotes()
        {
            return lstNotes.AsEnumerable();
        }

        [HttpGet("[action]")]
        [Route("GetNotesById/{noteId}")]
        public JsonResult GetNotesById(int noteId)
        {
            var note = lstNotes.Where(x => x.Id == noteId).FirstOrDefault();

            return Json(note);
        }

        public class WeatherForecast
        {
            public string DateFormatted { get; set; }
            public int TemperatureC { get; set; }
            public string Summary { get; set; }

            public int TemperatureF
            {
                get
                {
                    return 32 + (int)(TemperatureC / 0.5556);
                }
            }
        }

        public class Notes
        {
            public int Id { get; set; }
            public string Title { get; set; }
            public string Text { get; set; }
            public List<string> Tags { get; set; }
        }
    }
}
